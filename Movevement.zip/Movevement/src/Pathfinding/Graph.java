/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pathfinding;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sonho
 */
public class Graph {
    private double[][] matrix;
    private int size;
    private String filePath;

    public Graph(String filePath) {
        this.filePath = filePath;
        init();
    }

    
    public void init(){
       Scanner scanner = null;
        try {
            scanner = new Scanner(new File(filePath)); //mở rồi
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Graph.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(scanner != null){
       
            size = scanner.nextInt();
            matrix = new double[size][size];
            for (int i = 0; i < size; i++) {
                for(int j = 0; j < size; j++){
                    matrix[i][j] = scanner.nextDouble();
                }
            }
        }
//        size = scanner.nextInt();
//        System.out.println(size);
        scanner.close();
        
    }
    //nap du lieu, tạo mới đồ thị
    
    public List<Connection> getConnections(int fromNode){
        List<Connection> connections =  new ArrayList<>(); //dang list
        for (int i = 0; i < size; i++) {
            if(matrix[fromNode][i] != Double.MIN_VALUE){
                connections.add(new Connection(fromNode, i, matrix[fromNode][i]));
            }
        }
        return connections;
    }
    
    
     public static void main(String[] args) {
        Graph graph = new Graph("C:\\input.txt");
//         System.out.println(Double.MAX_VALUE);
        List<Connection> connections = graph.getConnections(0);
        for(Connection connection:connections){
            System.out.println(connection);
        }
    }
}

//muốn đuổi theo phải xác định dc vận tốc, phải biết phương chiều vtoc.
//tìm đường...
//thuat toán đi chuyển là đi giữa 2 điềm, tìm đường định ra tất cả các điểm trên đường đi.
//tìm đường đi ngắn nhất từ đỉnh này đến đỉnh kia là thuật toán dijkstra